let btnMenu = document.getElementById('btn-menu')
let menu = document.getElementById('menu-mobile')
let overlay = document.getElementById('overlay-menu')

btnMenu.addEventListener('click', ()=>{
    menu.classList.add('abrir-menu')
})
menu.addEventListener('click', ()=>{
    menu.classList.remove('abrir-menu')
})
overlay.addEventListener('click', ()=>{
    menu.classList.remove('abrir-menu')
})

document.addEventListener("DOMContentLoaded", function() {
    // Simulação de carregamento com um tempo de espera
    setTimeout(() => {
        const loader = document.querySelector(".loader-container");
        loader.classList.add("hidden");

        // Mostra o conteúdo principal
        content.classList.remove('hidden'); // Remove 'hidden' antes de adicionar 'visible'
        content.classList.add('visible');
    }, 3000); // 2 segundos de simulação de carregamento
});
window.addEventListener('load', () => {
    window.scrollTo(0, 0); // Garante que a página volta ao topo
});
